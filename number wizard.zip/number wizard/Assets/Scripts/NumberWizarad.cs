﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberWizarad : MonoBehaviour {
	    int max = 500;
		int min = 1;
		int guess = 250;
	// Use this for initialization
	void Start () {
		print ("Welcome To Number Wizard");
		print ("Pick a number in your head, but donʻt tell me");



		print ("The highest number you can pick is " + max);
		print ("the lowest number you can pick it " + min);

		print ("Is the number higher or lower than 250?");
		print ("Up = higher, down = lower, return = equal");
	}
	
	// Update is called once per frame
	void Update (){	  
	    if (Input.GetKeyDown (KeyCode.UpArrow)) {
	    min = guess;
	    guess = (max + min) / 2;
	    print ("Higher or lower then " + guess);
		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			max = guess;
	    guess = (max + min) / 2;
	    print ("Higher or lower then " + guess);
		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("I won!");
		}
	}
}